clear;
a = [ 1 2 
3 4  ];
b = [0
1];
x = a\b
 -3*a(1,:)+a(2,:)
inv(a)
