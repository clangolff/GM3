clear;
n=5;
a= hilb(n);
l= tril(a)
[il]=inve(l,n)
il*l
