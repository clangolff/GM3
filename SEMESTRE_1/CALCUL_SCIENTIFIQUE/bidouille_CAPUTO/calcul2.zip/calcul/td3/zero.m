clear all;
n=400;
x=1.;
for i=1:n
  x = x/10.;
  fprintf('%2d  %30.20g \n', i,x)
end

