for i in range (1,400):
	x= 10**(-i)
	print(i,x)
