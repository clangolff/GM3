clear;
n=5;
A=hilb(n); b = sum(A,2);
x= A \ b
