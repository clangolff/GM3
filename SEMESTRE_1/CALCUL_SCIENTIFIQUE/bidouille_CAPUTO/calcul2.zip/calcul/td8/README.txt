jac.py contient la version avec w = 0. jac2.py contient la version avec w = 2.

Pour w = 0, la solution de Ax=b ne converge pas vers un point fixe lorsque la dimension de la matrice A de hilbert devient trop grande. Ceci est dû au fait que la matrice de hilbert possède un rayon spectral plus grand que 1. 
En rajoutant un scalaire sur la diagonale de la matrice de hilbert, celle-ci devient à diagonale strictement dominante et donc peut converger vers une unique solution avec la méthode de Jacobi.
