clear all;
n = 10;
w = 4.0;
kmax = 100;
tol = 1.e-13;

A = hilb(n) + w*eye(n);
B = sum(A,2);
X0 = zeros(n,1);
L = zeros(n);
U = zeros(n);
D = diag(diag(A));  //le premier diag donne une ligne et le deuxiemme donne une matrice

for j = 1:n 
	L(j+1:n,j) = a(j+1:n,j);
	U(j,j+1:n) = a(j,j+1:n);
end

C = L+U;
E = inv(D)*B;

for k=1:kmax 
	X1 = -C*x0 + E;
	res = norm2(X1-X0);
	fprintf('%d  %.2f',k,res);
	if (res < tol) 
		break;
	end
	X0 = X1;
end

	
