import numpy as np
from scipy.linalg import hilbert

n = 10
w = 2.0
kmax = 100
tol = 1.e-15

#préparation des données
A = hilbert(n) + np.dot(w,np.eye(n))    
B = np.sum(A,axis = 1)      # B est une liste 
B = B.reshape(n,1)          # transforme B en tableau de n lignes et 1 colonne
        
#calcul de la décomposition de A
diag = np.diag(A)
invD = np.zeros((n,n))
for i in range(n) :
    invD[i,i] = 1 / diag[i]
    
C = np.matmul(invD,A) - np.identity(n)      
E = np.matmul(invD,B)

#recherche d'un point fixe ou d'une divergence
X0 = np.ones((n,1))

for i in range(kmax):
    X1 = - np.matmul(C,X0) + E
    res = np.linalg.norm(X1-X0)
    print(i,res)
    if res < tol : 
        break
    X0 = X1
print(X0)
