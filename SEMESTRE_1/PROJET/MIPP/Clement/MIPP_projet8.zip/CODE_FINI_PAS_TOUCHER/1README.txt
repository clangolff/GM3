Ce dossier contient les codes sources en C du programme :
	Les fichiers .h 
		- instruction.h    // bibliothèque pour manipuler le TAD instruction
		- liste.h                // bibliothèque pour manipuler le TAD liste
		- mysdl.h             // bibliothèque utilisant les fonctions de la bibliotheque SDL
	Les fichiers .c corespondant
		- instruction.c
		- liste.c 
		- mysdl.c
		- main.c                // programme principale
		
Les commandes pour compiler les programmes sont indiquées dans les fichiers .h ( attention commande valable sous linux ).
Un MakeFile a été créé mais ne fonctionne que pour instruction.o et liste.o . La commande pour compiler le main.c et mysdl.c fonctionne sur terminale uniquement, je n'ai pas trouver la solution pour réussir à compiler avec le MakeFile (problème avec la commande pour inclure la bibliothèque SDL).

Un fichier exemple.txt contenant des exemples d'instructions.

Le rapport en pdf du projet

Programmé et exécuté sous Linux Fedora36.


Langolff Clément
Kessler Aymeric

groupe 23


 
		
