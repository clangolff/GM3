Ce dossier est diviser en 2 parties :

Une partie code contenant : 
	- gradDescend_dim2.py   // affiche la matrice en dimension 2 et les itérés succéssifs de X par l'algorithme du gradient descente //
	- gradConj_dim2.py          // affiche la matrice en dimension 2 et les itérés successifs de X par l'algorithme du gradient conjugué //
	- comparaison_dimN.py   // affiche le nombre d'itération pour atteindre une solution inférieur à une certaine tolérance et comparaison entre l'algorithme du gradient descente et gradient conjugué //
	
Une partie rapport contenant le fichier pdf, le fichier latex ainsi que la bibliographie.
	
