Ce dossier comporte le rapport finale du projet de MSRO	3 au format pdf.
Le dossier code comporte tous les codes réaliser sur python pour réaliser les différentes simulations :

	- loi uniforme dans le disque unité
	- loi uniforme pour une fonction de répartition f
	- mix normale/uniforme pour une fonction de répartition f

Pour éxecuter les programmes, lancer :  $ python nom_programme.py


